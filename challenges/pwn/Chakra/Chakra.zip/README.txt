﻿Hey guys, this is a ChakraCore Vulnerability Challenge.Well,I am not expecting you to find a 0day in ChakraCore. In fact,i patch the master ChakraCore code and create a new Vulnerabilities where it doesn't exist. I provide the patch file here, and you can download the master ChakraCore code from github.
https://github.com/Microsoft/ChakraCore

I have provided the compiled binaries under Windows.If you think you can only use Linux to complete exploits. It's ok， you need provide me with the compiled binaries.

Please note that we do not accept unexpected solutions (for example, other 0 days or 1 days). You need to use my vulnerability patch to exploit.

First, you need to find the vulnerability and make a vulnerability analysis.
Second, you need to write a vulnerability exploit. The role of exploits does not matter, but you must implement control EIP and execute arbitrary code.
Finally, you need to provide me with complete exploit code and screen shots that demonstrate successful exploited.If you feel it is necessary that you can provide me with the corresponding binary file.

Mitigation:ASLR DEP CFG